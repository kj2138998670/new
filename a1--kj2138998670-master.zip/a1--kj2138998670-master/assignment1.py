"""
Replace the contents of this module docstring with your own details.
"""


def main():
    print("Songs To Learn 1.0 - by <Your Name>")


if __name__ == '__main__':
    main()
